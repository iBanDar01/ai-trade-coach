#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r requirements.txt
export $(grep -v '^#' .env 2>/dev/null | xargs -0 2>/dev/null) || true
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
