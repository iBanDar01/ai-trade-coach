@echo off
cd /d %~dp0
python -m venv .venv 2>NUL
call .venv\Scripts\activate
pip install -q -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
