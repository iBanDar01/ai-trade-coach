"""
Regenerates the app icons and iOS splash screens.
Run: python3 scripts/gen_icons.py
Requires: Pillow  (pip install pillow)

Everything is drawn in code (no external image assets), so there is
nothing to license and you can re-brand by editing the constants below.
"""
from __future__ import annotations
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
ICONS_DIR = ROOT / "app" / "static" / "icons"
SPLASH_DIR = ROOT / "app" / "static" / "splash"
ICONS_DIR.mkdir(parents=True, exist_ok=True)
SPLASH_DIR.mkdir(parents=True, exist_ok=True)

BG = (8, 11, 16, 255)          # app background
ACCENT_UP = (39, 209, 127, 255)   # green candle
ACCENT_DOWN = (255, 93, 108, 255) # red candle
TEXT = (233, 238, 245, 255)


def draw_mark(size: int, padding_ratio: float = 0.18) -> Image.Image:
    """A simple candlestick / uptrend glyph on a rounded dark square."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = int(size * 0.22)
    d.rounded_rectangle([0, 0, size - 1, size - 1], radius=r, fill=BG)

    pad = size * padding_ratio
    inner = size - pad * 2
    # three candlesticks forming an uptrend
    candles = [
        (0.00, 0.55, 0.85, ACCENT_DOWN),
        (0.36, 0.30, 0.65, ACCENT_UP),
        (0.72, 0.10, 0.45, ACCENT_UP),
    ]
    cw = inner * 0.20
    for (x_ratio, top_ratio, bot_ratio, color) in candles:
        x = pad + inner * x_ratio
        top = pad + inner * top_ratio
        bot = pad + inner * bot_ratio
        wick_x = x + cw / 2
        d.line([(wick_x, top - inner * 0.06), (wick_x, bot + inner * 0.06)],
               fill=color, width=max(2, int(size * 0.012)))
        d.rounded_rectangle([x, top, x + cw, bot], radius=cw * 0.25, fill=color)
    return img


def save_icon(size: int, name: str, maskable_padding: bool = False):
    if maskable_padding:
        # keep the glyph inside the safe zone for adaptive/maskable icons
        img = Image.new("RGBA", (size, size), BG)
        mark = draw_mark(int(size * 0.7))
        img.alpha_composite(mark, ((size - mark.width) // 2, (size - mark.height) // 2))
    else:
        img = draw_mark(size, padding_ratio=0.16)
    img.convert("RGB").save(ICONS_DIR / name, "PNG")


def save_splash(w: int, h: int, name: str):
    img = Image.new("RGB", (w, h), BG[:3])
    d = ImageDraw.Draw(img)
    mark_size = int(min(w, h) * 0.22)
    mark = draw_mark(mark_size)
    img.paste(mark, ((w - mark_size) // 2, (h - mark_size) // 2 - int(h * 0.03)), mark)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(h * 0.028))
    except Exception:
        font = ImageFont.load_default()
    label = "AI TRADE COACH"
    bbox = d.textbbox((0, 0), label, font=font)
    tw = bbox[2] - bbox[0]
    d.text(((w - tw) / 2, (h // 2) + mark_size // 2), label, fill=TEXT, font=font)
    img.save(SPLASH_DIR / name, "PNG")


ICON_SIZES = [
    (192, "icon-192.png", False),
    (512, "icon-512.png", False),
    (180, "apple-touch-icon.png", False),
    (1024, "icon-maskable-1024.png", True),
]

# (width, height, device label) — portrait, CSS-pixel * device scale factor.
# This is a representative set; add more from Apple's HIG splash-screen
# table if you need pixel-perfect splash on every model.
SPLASH_SIZES = [
    (1290, 2796, "splash-1290x2796.png"),  # iPhone 15/14 Pro Max
    (1179, 2556, "splash-1179x2556.png"),  # iPhone 15/14 Pro
    (1170, 2532, "splash-1170x2532.png"),  # iPhone 13/12/14
    (1242, 2688, "splash-1242x2688.png"),  # iPhone 11 Pro Max / XS Max
    (828, 1792, "splash-828x1792.png"),    # iPhone 11 / XR
    (750, 1334, "splash-750x1334.png"),    # iPhone SE / 8
]

if __name__ == "__main__":
    for size, name, maskable in ICON_SIZES:
        save_icon(size, name, maskable)
    for w, h, name in SPLASH_SIZES:
        save_splash(w, h, name)
    print(f"Wrote {len(ICON_SIZES)} icons to {ICONS_DIR}")
    print(f"Wrote {len(SPLASH_SIZES)} splash screens to {SPLASH_DIR}")
