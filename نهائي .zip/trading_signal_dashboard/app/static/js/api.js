const Api = (() => {
  let online = navigator.onLine;
  const listeners = [];

  function setOnline(v) {
    if (v === online) return;
    online = v;
    listeners.forEach((fn) => fn(online));
  }

  window.addEventListener('online', () => setOnline(true));
  window.addEventListener('offline', () => setOnline(false));

  async function call(url, opts = {}) {
    let res;
    try {
      res = await fetch(url, opts);
    } catch (e) {
      setOnline(false);
      throw new Error('OFFLINE');
    }
    setOnline(true);
    let data = {};
    try { data = await res.json(); } catch { /* no body */ }
    if (!res.ok) {
      throw new Error(data.detail || data.message || `HTTP ${res.status}`);
    }
    return data;
  }

  return {
    get: (url) => call(url),
    post: (url, body) => call(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
    postForm: (url, formData) => call(url, { method: 'POST', body: formData }),
    del: (url) => call(url, { method: 'DELETE' }),
    isOnline: () => online,
    onStatusChange: (fn) => listeners.push(fn),
  };
})();
