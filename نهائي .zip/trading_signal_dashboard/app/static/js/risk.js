const RiskView = (() => {
  function money(x) {
    return Number(x).toLocaleString(undefined, { style: 'currency', currency: 'USD' });
  }

  async function recalc({ balanceEl, riskPctEl, lossLimitPctEl, resultEl }) {
    const payload = {
      balance: parseFloat(balanceEl.value || '0'),
      risk_per_trade_pct: parseFloat(riskPctEl.value || '0'),
      daily_loss_limit_pct: parseFloat(lossLimitPctEl.value || '0'),
      trades_today: 0,
      daily_pnl: 0,
    };
    try {
      const r = await Api.post('/api/risk/calc', payload);
      resultEl.innerHTML = `
        <p>Suggested stake per trade: <b>${money(r.suggested_stake)}</b></p>
        <p>Daily loss limit: <b>${money(r.daily_loss_limit_amount)}</b></p>
      `;
    } catch (e) {
      resultEl.innerHTML = `<p style="color:var(--red)">${e.message}</p>`;
    }
  }

  return { recalc };
})();
