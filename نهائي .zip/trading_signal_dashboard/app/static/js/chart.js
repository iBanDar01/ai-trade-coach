const ChartView = (() => {
  function draw(canvas, candles) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 320;
    const h = canvas.clientHeight || 220;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!candles || !candles.length) return;

    const vals = candles.flatMap((k) => [k.high, k.low]);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const pad = 16;
    const xstep = (w - pad * 2) / candles.length;
    const y = (v) => pad + ((max - v) / (max - min || 1)) * (h - pad * 2);

    ctx.strokeStyle = '#1c2432';
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
      const yy = pad + (i * (h - pad * 2)) / 3;
      ctx.beginPath();
      ctx.moveTo(pad, yy);
      ctx.lineTo(w - pad, yy);
      ctx.stroke();
    }

    candles.forEach((k, i) => {
      const x = pad + i * xstep + xstep / 2;
      const up = k.close >= k.open;
      ctx.strokeStyle = up ? '#27d17f' : '#ff5d6c';
      ctx.fillStyle = ctx.strokeStyle;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, y(k.high));
      ctx.lineTo(x, y(k.low));
      ctx.stroke();
      const top = y(Math.max(k.open, k.close));
      const bot = y(Math.min(k.open, k.close));
      const bw = Math.max(2, xstep * 0.55);
      ctx.fillRect(x - bw / 2, top, bw, Math.max(1.5, bot - top));
    });
  }

  return { draw };
})();
