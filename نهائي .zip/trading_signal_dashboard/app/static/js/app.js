(() => {
  const $ = (id) => document.getElementById(id);
  const settings = AppState.get();

  let analysisBusy = false;
  let focusTimerInterval = null;
  let pollTimer = null;

  // ---------------- Tabs ----------------
  function showView(viewId) {
    document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === viewId));
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === viewId));
    if (viewId === 'view-history') loadHistory();
    if (viewId === 'view-risk') recalcRisk();
    if (viewId === 'view-settings') syncSettingsUI();
  }
  document.querySelectorAll('.tab-btn').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));

  // ---------------- Connection status ----------------
  function setSourceChip(mode, label) {
    const chip = $('sourceChip');
    chip.className = `status-chip ${mode}`;
    $('sourceChipText').textContent = label;
  }
  Api.onStatusChange((online) => {
    $('offlineBanner').hidden = online;
    if (!online) setSourceChip('offline', 'DISCONNECTED');
  });

  // ---------------- Install hint (iOS Safari, not yet installed) ----------------
  function isIOS() { return /iphone|ipad|ipod/i.test(navigator.userAgent); }
  function isStandalone() { return navigator.standalone === true || matchMedia('(display-mode: standalone)').matches; }
  function maybeShowInstallHint() {
    if (isIOS() && !isStandalone() && !AppState.get().hideInstallHint) $('installHint').hidden = false;
  }
  $('dismissInstallHint').addEventListener('click', () => {
    AppState.set({ hideInstallHint: true });
    $('installHint').hidden = true;
  });

  // ---------------- Focus mode ----------------
  function toggleFocusMode() {
    document.body.classList.toggle('focus-mode');
  }
  $('focusToggleBtn').addEventListener('click', toggleFocusMode);

  function startFocusTimer(durationLabel) {
    clearInterval(focusTimerInterval);
    const secs = parseDuration(durationLabel);
    const timerCard = $('focusTimerCard');
    if (!secs) { timerCard.hidden = true; return; }
    let remaining = secs;
    timerCard.hidden = false;
    const render = () => {
      const m = Math.floor(remaining / 60).toString().padStart(2, '0');
      const s = Math.floor(remaining % 60).toString().padStart(2, '0');
      $('focusTimer').textContent = `${m}:${s}`;
    };
    render();
    focusTimerInterval = setInterval(() => {
      remaining -= 1;
      if (remaining <= 0) { clearInterval(focusTimerInterval); $('focusTimer').textContent = 'Window closed'; return; }
      render();
    }, 1000);
  }
  function parseDuration(label) {
    if (!label) return 0;
    const m = String(label).match(/(\d+)\s*(s|m)/i);
    if (!m) return 0;
    const n = parseInt(m[1], 10);
    return m[2].toLowerCase() === 'm' ? n * 60 : n;
  }

  // ---------------- Signal rendering ----------------
  function riskLevelFor(confidence) {
    if (confidence >= 80) return 'Low';
    if (confidence >= 65) return 'Medium';
    return 'High';
  }

  function renderSignal(sig, sourceLabel) {
    const action = (sig.action || 'WAIT').toUpperCase();
    const cls = action === 'BUY' ? 'buy' : action === 'SELL' ? 'sell' : 'wait';

    $('signalCard').className = `card signal-card ${cls}`;
    $('actionLabel').className = `action-label ${cls}`;
    $('actionLabel').textContent = action === 'BUY' ? 'BUY ↑' : action === 'SELL' ? 'SELL ↓' : 'WAIT';
    $('durationPill').textContent = sig.duration || '—';
    $('riskLevelPill').textContent = action === 'WAIT' ? '—' : riskLevelFor(sig.confidence || 0);
    $('confidenceText').textContent = `${sig.confidence || 0}%`;
    const fill = $('confidenceFill');
    fill.className = `confidence-fill ${cls}`;
    fill.style.width = `${sig.confidence || 0}%`;

    const reasons = sig.reasons || (sig.reason ? [sig.reason] : []);
    $('reasonShort').textContent = action === 'WAIT'
      ? (reasons[0] || 'No clear setup right now — indicators are mixed or insufficient.')
      : (reasons[0] || '');
    $('reasonList').innerHTML = reasons.map((r) => `<li>${r}</li>`).join('');

    const warnBox = $('warningBox');
    if (sig.warning) { warnBox.hidden = false; warnBox.textContent = sig.warning; }
    else { warnBox.hidden = true; }

    if (sig.price !== undefined && sig.price !== null) $('assetPrice').textContent = sig.price;
    if (sig.asset) $('assetName').textContent = sig.asset;

    if (action !== 'WAIT') startFocusTimer(sig.duration);
    else { clearInterval(focusTimerInterval); $('focusTimerCard').hidden = true; }

    Notify.signal(sig, AppState.get());
  }

  // ---------------- Demo live state polling ----------------
  async function loadState() {
    try {
      const s = await Api.get('/api/state');
      setSourceChip('live', 'LIVE DATA (DEMO)');
      $('balanceText').textContent = Math.round(s.balance);
      $('pnlText').textContent = (s.daily_pnl >= 0 ? '+' : '') + s.daily_pnl.toFixed(2);
      $('tradesText').textContent = s.trades_today;
      renderSignal({ action: s.signal.side.replace('/CALL', '').replace('/PUT', ''), confidence: s.signal.confidence, duration: '1m', reasons: s.signal.reasons, price: s.signal.price }, 'LIVE_DATA');
      ChartView.draw($('chartCanvas'), s.candles);
    } catch (e) {
      if (e.message === 'OFFLINE') setSourceChip('offline', 'DISCONNECTED');
    }
  }
  async function tick() {
    try { await Api.post('/api/tick', {}); await loadState(); } catch { /* ignore transient errors */ }
  }
  $('tradeBuyBtn').addEventListener('click', () => trade('BUY'));
  $('tradeSellBtn').addEventListener('click', () => trade('SELL'));
  async function trade(side) {
    try {
      const r = await Api.post('/api/paper-trade', { side });
      if (!r.ok) { alert(r.message); return; }
      loadState();
    } catch (e) { alert(e.message); }
  }

  // ---------------- Screenshot analysis ----------------
  $('analyzeBtn').addEventListener('click', () => $('shotInput').click());
  $('shotInput').addEventListener('change', () => {
    const file = $('shotInput').files[0];
    if (file) analyzeBlob(file);
    $('shotInput').value = '';
  });

  async function analyzeBlob(blob) {
    if (analysisBusy) return;
    analysisBusy = true;
    $('coachMessage').textContent = 'Analyzing screenshot…';
    setSourceChip('screenshot', 'SCREENSHOT');
    try {
      const fd = new FormData();
      fd.append('image', blob, 'screen.jpg');
      const r = await Api.postForm('/api/analyze-screen', fd);
      renderSignal(r.signal, 'SCREENSHOT');
      $('coachMessage').textContent = `Last analyzed: ${new Date().toLocaleTimeString()}`;
    } catch (e) {
      $('coachMessage').textContent = e.message === 'OFFLINE'
        ? 'Offline — connect to analyze a screenshot.'
        : e.message;
    } finally {
      analysisBusy = false;
    }
  }

  // ---------------- Expand / collapse full analysis ----------------
  $('expandBtn').addEventListener('click', () => {
    const list = $('reasonList');
    const willShow = list.hidden;
    list.hidden = !willShow;
    $('expandBtn').textContent = willShow ? 'Hide full analysis' : 'Show full analysis';
  });

  // ---------------- History ----------------
  async function loadHistory() {
    try {
      const r = await Api.get('/api/history?limit=100');
      HistoryView.renderStats($('historyStats'), r.stats);
      HistoryView.renderList($('historyList'), r.records, setOutcome);
    } catch (e) {
      $('historyList').innerHTML = `<p style="color:var(--red);font-size:13px;">${e.message}</p>`;
    }
  }
  async function setOutcome(id, outcome) {
    try { await Api.post(`/api/history/${id}/outcome`, { outcome }); loadHistory(); }
    catch (e) { alert(e.message); }
  }
  $('clearHistoryBtn').addEventListener('click', async () => {
    if (!confirm('Clear all logged signal history?')) return;
    try { await Api.del('/api/history'); loadHistory(); } catch (e) { alert(e.message); }
  });

  // ---------------- Risk tab ----------------
  function recalcRisk() {
    RiskView.recalc({
      balanceEl: $('riskBalance'), riskPctEl: $('riskPct'), lossLimitPctEl: $('riskLossLimit'), resultEl: $('riskResult'),
    });
  }
  ['riskBalance', 'riskPct', 'riskLossLimit'].forEach((id) => $(id).addEventListener('input', recalcRisk));

  // ---------------- Settings ----------------
  function syncSettingsUI() {
    const s = AppState.get();
    $('swNotify').checked = s.notifyEnabled;
    $('swHighConf').checked = s.notifyHighConfidenceOnly;
    $('swSound').checked = s.soundEnabled;
    $('swVibration').checked = s.vibrationEnabled;
  }
  $('swNotify').addEventListener('change', async (e) => {
    if (e.target.checked && Notify.permission() !== 'granted') {
      const p = await Notify.requestPermission();
      if (p !== 'granted') { e.target.checked = false; AppState.set({ notifyEnabled: false }); return; }
    }
    AppState.set({ notifyEnabled: e.target.checked });
  });
  $('swHighConf').addEventListener('change', (e) => AppState.set({ notifyHighConfidenceOnly: e.target.checked }));
  $('swSound').addEventListener('change', (e) => AppState.set({ soundEnabled: e.target.checked }));
  $('swVibration').addEventListener('change', (e) => AppState.set({ vibrationEnabled: e.target.checked }));
  $('enableNotifyBtn').addEventListener('click', async () => {
    const p = await Notify.requestPermission();
    alert(p === 'granted' ? 'Notifications enabled.' : 'Notifications were not allowed.');
  });

  $('exportBtn').addEventListener('click', () => {
    const blob = new Blob([AppState.exportJson()], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'ai-trade-coach-settings.json'; a.click();
    URL.revokeObjectURL(url);
  });
  $('importBtn').addEventListener('click', () => $('importInput').click());
  $('importInput').addEventListener('change', async () => {
    const file = $('importInput').files[0];
    if (!file) return;
    try {
      AppState.importJson(await file.text());
      syncSettingsUI();
      alert('Settings imported.');
    } catch { alert('Could not read that file.'); }
    $('importInput').value = '';
  });
  $('resetSettingsBtn').addEventListener('click', () => {
    if (!confirm('Reset all settings to defaults?')) return;
    AppState.reset();
    syncSettingsUI();
  });

  async function checkAiStatus() {
    try {
      const s = await Api.get('/api/ai-status');
      $('aiStatusText').textContent = s.configured
        ? `Ready (model: ${s.model}).`
        : 'Not configured yet — set OPENAI_API_KEY on the server to enable screenshot analysis.';
    } catch { $('aiStatusText').textContent = 'Could not check status.'; }
  }

  // ---------------- Boot ----------------
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
  loadState();
  checkAiStatus();
  maybeShowInstallHint();
  pollTimer = setInterval(tick, 10000);
  window.addEventListener('resize', () => loadState());
})();
