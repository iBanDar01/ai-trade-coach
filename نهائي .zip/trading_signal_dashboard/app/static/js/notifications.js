const Notify = (() => {
  let lastKey = '';

  function supported() {
    return 'Notification' in window;
  }

  async function requestPermission() {
    if (!supported()) return 'unsupported';
    try { return await Notification.requestPermission(); } catch { return 'denied'; }
  }

  function permission() {
    return supported() ? Notification.permission : 'unsupported';
  }

  function vibrate(pattern) {
    if (navigator.vibrate) { try { navigator.vibrate(pattern); } catch { /* ignore */ } }
  }

  function beep() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      const ctx = new Ctx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 880;
      gain.gain.value = 0.05;
      osc.connect(gain).connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch { /* ignore */ }
  }

  async function signal(sig, settings) {
    if (sig.action === 'WAIT') return;
    if (!settings.notifyEnabled) return;
    if (settings.notifyHighConfidenceOnly && sig.confidence < 75) return;

    const key = `${sig.action}|${sig.duration}|${sig.confidence}`;
    if (settings.notifyOnlyOnChange && key === lastKey) return;
    lastKey = key;

    if (settings.soundEnabled) beep();
    if (settings.vibrationEnabled) vibrate([60, 40, 60]);

    if (permission() !== 'granted') return;
    const title = sig.action === 'BUY' ? 'Suggestion: BUY ↑' : 'Suggestion: SELL ↓';
    const body = `${sig.duration} • Confidence ${sig.confidence}% • ${(sig.reasons || [])[0] || ''}`;
    const opts = { body, icon: '/static/icons/icon-192.png', badge: '/static/icons/icon-192.png', tag: 'trade-signal', renotify: true };
    if (navigator.serviceWorker && navigator.serviceWorker.ready) {
      try {
        const reg = await navigator.serviceWorker.ready;
        reg.showNotification(title, opts);
        return;
      } catch { /* fall through */ }
    }
    try { new Notification(title, opts); } catch { /* ignore */ }
  }

  return { supported, requestPermission, permission, signal };
})();
