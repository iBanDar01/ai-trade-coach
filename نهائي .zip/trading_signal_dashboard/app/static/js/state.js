const AppState = (() => {
  const KEY = 'aiTradeCoach.settings.v1';

  const defaults = {
    balance: 1000,
    riskPerTradePct: 1,
    dailyLossLimitPct: 5,
    notifyEnabled: false,
    notifyHighConfidenceOnly: true,
    notifyOnlyOnChange: true,
    soundEnabled: true,
    vibrationEnabled: true,
    hideInstallHint: false,
    minConfidenceToShow: 0, // client-side extra filter, on top of the server's own 65% floor
  };

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return { ...defaults };
      return { ...defaults, ...JSON.parse(raw) };
    } catch {
      return { ...defaults };
    }
  }

  let settings = load();

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch { /* storage unavailable */ }
  }

  function get() { return settings; }
  function set(patch) { settings = { ...settings, ...patch }; save(); return settings; }
  function exportJson() { return JSON.stringify(settings, null, 2); }
  function importJson(text) {
    const parsed = JSON.parse(text);
    settings = { ...defaults, ...parsed };
    save();
    return settings;
  }
  function reset() { settings = { ...defaults }; save(); return settings; }

  return { get, set, exportJson, importJson, reset };
})();
