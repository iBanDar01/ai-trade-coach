const HistoryView = (() => {
  const ACTION_LABEL = { BUY: 'BUY ↑', SELL: 'SELL ↓', WAIT: 'WAIT' };

  function fmtTime(iso) {
    try {
      return new Date(iso).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch { return iso; }
  }

  function renderStats(el, stats) {
    if (!el) return;
    const winRate = stats.win_rate === null || stats.win_rate === undefined ? '—' : `${stats.win_rate}%`;
    el.innerHTML = `
      <div class="stat-box"><div class="num">${stats.total_signals}</div><div class="lbl">Signals</div></div>
      <div class="stat-box"><div class="num" style="color:var(--green)">${stats.wins}</div><div class="lbl">Wins</div></div>
      <div class="stat-box"><div class="num" style="color:var(--red)">${stats.losses}</div><div class="lbl">Losses</div></div>
      <div class="stat-box"><div class="num">${stats.skipped}</div><div class="lbl">Skipped</div></div>
      <div class="stat-box"><div class="num">${stats.wait_signals}</div><div class="lbl">Wait</div></div>
      <div class="stat-box"><div class="num">${winRate}</div><div class="lbl">Win rate</div></div>
    `;
  }

  function renderList(el, records, onOutcome) {
    if (!el) return;
    if (!records.length) {
      el.innerHTML = '<p style="color:var(--text-dim);font-size:13px;">No signals logged yet.</p>';
      return;
    }
    el.innerHTML = '';
    records.forEach((r) => {
      const row = document.createElement('div');
      row.className = 'history-item';
      const actionCls = r.action.toLowerCase();
      row.innerHTML = `
        <div class="history-left">
          <span class="history-asset">${r.asset || 'Unknown'} <span class="history-action ${actionCls}">${ACTION_LABEL[r.action] || r.action}</span></span>
          <span class="history-time">${fmtTime(r.time)} • ${r.duration || '—'} • ${r.confidence}% • ${r.source}</span>
        </div>
        <div class="outcome-btns" data-id="${r.id}">
          <button data-outcome="WIN" class="${r.outcome === 'WIN' ? 'active win' : ''}">Win</button>
          <button data-outcome="LOSS" class="${r.outcome === 'LOSS' ? 'active loss' : ''}">Loss</button>
          <button data-outcome="SKIPPED" class="${r.outcome === 'SKIPPED' ? 'active skip' : ''}">Skip</button>
        </div>
      `;
      row.querySelectorAll('[data-outcome]').forEach((btn) => {
        btn.addEventListener('click', () => onOutcome(r.id, btn.dataset.outcome));
      });
      el.appendChild(row);
    });
  }

  return { renderStats, renderList };
})();
